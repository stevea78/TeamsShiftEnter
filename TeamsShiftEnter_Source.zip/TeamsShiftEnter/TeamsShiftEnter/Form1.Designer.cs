﻿namespace TeamsShiftEnter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.labelStatusLabel = new System.Windows.Forms.Label();
            this.labelStatusResult = new System.Windows.Forms.Label();
            this.buttonStartStop = new System.Windows.Forms.Button();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelStatusLabel
            // 
            this.labelStatusLabel.AutoSize = true;
            this.labelStatusLabel.Location = new System.Drawing.Point(25, 22);
            this.labelStatusLabel.Name = "labelStatusLabel";
            this.labelStatusLabel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.labelStatusLabel.Size = new System.Drawing.Size(40, 13);
            this.labelStatusLabel.TabIndex = 0;
            this.labelStatusLabel.Text = ":Status";
            // 
            // labelStatusResult
            // 
            this.labelStatusResult.AutoSize = true;
            this.labelStatusResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelStatusResult.Location = new System.Drawing.Point(71, 22);
            this.labelStatusResult.Name = "labelStatusResult";
            this.labelStatusResult.Size = new System.Drawing.Size(72, 13);
            this.labelStatusResult.TabIndex = 1;
            this.labelStatusResult.Text = "UNKNOWN";
            // 
            // buttonStartStop
            // 
            this.buttonStartStop.Location = new System.Drawing.Point(204, 17);
            this.buttonStartStop.Name = "buttonStartStop";
            this.buttonStartStop.Size = new System.Drawing.Size(75, 23);
            this.buttonStartStop.TabIndex = 2;
            this.buttonStartStop.UseVisualStyleBackColor = true;
            this.buttonStartStop.Click += new System.EventHandler(this.buttonStartStop_Click);
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "Teams SHIFT+ENTER";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseClick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(114, 0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(8, 8);
            this.button1.TabIndex = 3;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(291, 57);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonStartStop);
            this.Controls.Add(this.labelStatusResult);
            this.Controls.Add(this.labelStatusLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Teams SHIFT+ENTER";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelStatusLabel;
        private System.Windows.Forms.Label labelStatusResult;
        private System.Windows.Forms.Button buttonStartStop;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.Button button1;
    }
}

