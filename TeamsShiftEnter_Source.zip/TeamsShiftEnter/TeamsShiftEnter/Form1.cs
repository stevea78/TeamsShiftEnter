﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace TeamsShiftEnter
{
    public partial class Form1 : Form
    {
        private const int WH_KEYBOARD_LL = 13;
        private const int WM_KEYDOWN = 0x0100;
        private static LowLevelKeyboardProc _proc;
        private static IntPtr _hookID = IntPtr.Zero;

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelKeyboardProc lpfn, IntPtr hMod, uint dwThreadId);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool UnhookWindowsHookEx(IntPtr hhk);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string lpModuleName);

        [DllImport("user32.dll")]
        private static extern IntPtr GetForegroundWindow();

        [DllImport("user32.dll")]
        private static extern IntPtr GetWindowThreadProcessId(IntPtr hWnd, out Int32 ProcessId);

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _proc = HookCallback;
            SetActive();
        }

        private void SetActive()
        {
            _hookID = SetHook(_proc);
            labelStatusResult.Text = "ACTIVE";
            labelStatusResult.ForeColor = Color.Green;
            this.Icon = Properties.Resources.TeamsShiftEnterActive;
            notifyIcon1.Icon = Properties.Resources.TeamsShiftEnterActive;
            notifyIcon1.Text = "Teams SHIFT+ENTER - Active";
            buttonStartStop.Text = "Stop";
        }

        private void SetInactive()
        {
            UnhookWindowsHookEx(_hookID);
            labelStatusResult.Text = "INACTIVE";
            labelStatusResult.ForeColor = Color.Red;
            this.Icon = Properties.Resources.TeamsShiftEnterInactive;
            notifyIcon1.Icon = Properties.Resources.TeamsShiftEnterInactive;
            notifyIcon1.Text = "Teams SHIFT+ENTER - Inactive";
            buttonStartStop.Text = "Start";
        }

        private void buttonStartStop_Click(object sender, EventArgs e)
        {
            if (buttonStartStop.Text == "Start")
            {
                SetActive();
            }
            else
            {
                SetInactive();
            }
        }

        private static IntPtr SetHook(LowLevelKeyboardProc proc)
        {
            using (Process curProcess = Process.GetCurrentProcess())
            using (ProcessModule curModule = curProcess.MainModule)
            {
                return SetWindowsHookEx(WH_KEYBOARD_LL, proc, GetModuleHandle(curModule.ModuleName), 0);
            }
        }

        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);

        private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && wParam == (IntPtr)WM_KEYDOWN)
            {
                if (labelStatusResult.Text == "ACTIVE")
                {
                    int vkCode = Marshal.ReadInt32(lParam);
                    if ((Keys)vkCode == Keys.Enter && Control.ModifierKeys == Keys.None)
                    {
                        if (GetProcessNameFromWindowHandle(GetActiveWindow()).ToLower() == "teams.exe")
                        {
                            SendKeys.SendWait("+{ENTER}");
                            return (IntPtr)1;
                        }
                    }
                }
            }
            return CallNextHookEx(_hookID, nCode, wParam, lParam);
        }

        private static IntPtr GetActiveWindow()
        {
            return GetForegroundWindow();
        }

        private static Int32 GetWindowProcessID(IntPtr hwnd)
        {
            Int32 pid = 1;
            GetWindowThreadProcessId(hwnd, out pid);
            return pid;
        }

        private static string GetProcessNameFromWindowHandle(IntPtr hwnd)
        {
            Int32 pid = GetWindowProcessID(hwnd);
            Process p = Process.GetProcessById(pid);
            return p.MainModule.ModuleName;
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                Hide();
            }
        }

        private void notifyIcon1_MouseClick(object sender, MouseEventArgs e)
        {
            if (this.WindowState == FormWindowState.Minimized)
            {
                Show();
                this.WindowState = FormWindowState.Normal;
            }
            else if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Minimized;
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            switch (MessageBox.Show(this, "Are you sure you want to close?", "Closing", MessageBoxButtons.YesNo))
            {
                case DialogResult.No:
                    e.Cancel = true;
                    break;
                default:
                    SetInactive();
                    break;
            }
        }
    }
}